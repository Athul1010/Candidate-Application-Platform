import React from 'react'
import Product from './Product'

const Dashboard = () => {
  return (
    <div>
      <Product/>
    </div>
  )
}

export default Dashboard
