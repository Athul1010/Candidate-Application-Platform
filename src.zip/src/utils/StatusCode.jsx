const StatusCode = {
    LOADING : 'loading',
    IDLE : 'idle',
    ERROR : 'error'
}
export default StatusCode;